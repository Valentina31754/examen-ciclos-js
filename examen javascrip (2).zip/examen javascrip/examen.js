//1.	realice un ciclo que cuente del 1 al 10.
/*
var contador=1;

while(contador<=10){
    document.write(contador+"<br>");
    contador++;
}


for(contador=1;contador<=10;contador++){
    document.write(contador+"<br>");
}



2.	realice el mismo ejercicio anterior pero esta vez 
el límite del ciclo debe ser cualquier
 número que digite el usuario.

 var i=1;
 var limite= parseInt(prompt("dijite limite del ciclo"));

 while(i<=limite){
    document.write(i+"<br>");
    i++;

 }

 var limite= parseInt(prompt("dijite limite del ciclo que desee"));
 for(i=1;i<=limite;i++){
    document.write(i+"<br>");
 }

// 3.	realice un ciclo que empieza en 20 y termina en 1.

var contador=20;

while(contador>=1){
    document.write(contador+"<br>");
    contador--;

}

for(contador=20;contador>=1;contador--){
    document.write(contador+"<br>");
}



4.	Realice el ejercicio anterior pero esta 
vez que empiece en 50 y termine en 1, y los intervalos
 deben ser cualquier número que digite el usuario.


 var i=50;
 var intervalo=parseInt(prompt("dijite el intervalo"));

 while(i>=1){
    document.write(i+"<br>");
    i-=intervalo;

 }
 var intervalo=parseInt(prompt("dijite el intervalo"));
 for(i=50;i>1;i-=intervalo){
    document.write(i+"<br>");
 }

 
 
5.	realice un ciclo que pida el valor de productos 
hasta que digites la palabra “parar”,
 al final mostrar cuantos productos compró y el total a pagar.


var contador=0;
var pregunta=prompt("desea comprar");
var suma=0;
var Productos = "";

while(pregunta != "parar"){
    var valorP=parseInt(prompt("dijite el precio del producto"));
    suma=suma+valorP;
    Productos=Productos+valorP+" ";
    pregunta=prompt("desea comprar");
    contador++;
}
 
document.write("la cantidad de productos que compro es:" +Productos+ "<br>");
document.write("el total a pagar es"+suma+"<br>");
document.write("cantidad "+contador+"<br>");*/


var pregunta=prompt("desea comprar");
var suma=0;
var Productos = "";

for(contador=0;pregunta != "parar";  contador++){
    var valorP=parseInt(prompt("dijite el precio del producto"));
    suma=suma+valorP;
    Productos=Productos+valorP+" ";
    pregunta=prompt("desea comprar");


}

document.write("la cantidad de productos que compro es:" +Productos+ "<br>");
document.write("el total a pagar es"+suma+"<br>");
document.write("cantidad "+contador+"<br>");

